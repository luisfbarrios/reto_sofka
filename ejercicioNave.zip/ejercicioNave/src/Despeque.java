

public class Despeque implements  Funciones_naves{
    public void Acelerar_nave(){
        System.out.println("Aceleracion maxima y despegue");

    }
    public void AterrizaNave(){
        System.out.println("Prueba de vuelo exitosa comenzamos con el aterrizaje");

    }
    
}
