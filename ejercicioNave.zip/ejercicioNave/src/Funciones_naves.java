import java.util.function.Function;

public interface Funciones_naves {
    
    void Acelerar_nave();
    void AterrizaNave();
    
}
