import java.util.Scanner;



class Naves extends Vehiculo_aereo{
   
    


    public void tipo_nave() {
        System.out.println("Selecciona el tipo de nave");

    }

    public void seleccionar_nave() {
        System.out.println("Escribe 1, 2 o 3");

    }
        

         
   



    
    
}
